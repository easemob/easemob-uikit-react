import{N as i,c}from"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./jsx-runtime-CiKstLBL.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";const e="zh",s={en:{prefix:"prefix",className:"className",noticeMessage:"noticeMessage",style:"style"},zh:{prefix:"前缀",className:"类名",noticeMessage:"消息体",style:"样式"}},w={title:"Module/NoticeMessage",component:i,argTypes:{prefix:{control:"text",description:s[e].prefix},className:{control:"text",description:s[e].className},noticeMessage:{control:"object",description:s[e].noticeMessage,table:{type:{summary:"NoticeMessageBody"},details:{summary:'new NoticeMessageBody({ time: Date.now(), noticeType: "recall" })'}}},style:{control:"object",description:s[e].style}}},t={args:{noticeMessage:new c({time:Date.now(),noticeType:"recall"})}};var o,r,a;t.parameters={...t.parameters,docs:{...(o=t.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    noticeMessage: new NoticeMessageBody({
      time: Date.now(),
      noticeType: 'recall'
    })
  }
}`,...(a=(r=t.parameters)==null?void 0:r.docs)==null?void 0:a.source}}};const B=["Primary"];export{t as Primary,B as __namedExportsOrder,w as default};
