import{T as i}from"./Typing-CSYvUo61.js";import{r as a}from"./index-DzFcepMq.js";import"./jsx-runtime-CiKstLBL.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./index-RzZosPvc.js";import"./rootContext-c98KtOd0.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./reactNode-CrwpwiaA.js";import"./index-ux5NTfpI.js";import"./Icon-CScj7eB3.js";const o="zh",e={en:{prefix:"css class name prefix",className:"css class name",style:"css style",onHide:"Callback when hiding",onShow:"Callback when showing",conversation:"conversation"},zh:{prefix:"类名前缀",className:"类名",style:"样式",onHide:"隐藏回调",onShow:"显示回调",conversation:"会话"}},w={title:"Module/Typing",component:i,argTypes:{prefix:{description:e[o].prefix,control:{type:"text"}},className:{description:e[o].className,control:{type:"text"}},style:{description:e[o].style,control:{type:"object"}},onHide:{description:e[o].onHide},onShow:{description:e[o].onShow},conversation:{description:e[o].conversation,control:{type:"object"},table:{type:{summary:"CurrentConversation"}}}}};a.messageStore.setTyping({chatType:"singleChat",conversationId:"zd2"},!0);const t={args:{conversation:{chatType:"singleChat",conversationId:"zd2",name:"Henry"}}};var n,r,s;t.parameters={...t.parameters,docs:{...(n=t.parameters)==null?void 0:n.docs,source:{originalSource:`{
  args: {
    conversation: {
      chatType: 'singleChat',
      conversationId: 'zd2',
      name: 'Henry'
    }
  }
}`,...(s=(r=t.parameters)==null?void 0:r.docs)==null?void 0:s.source}}};const C=["Primary"];export{t as Primary,C as __namedExportsOrder,w as default};
