import{j as a}from"./jsx-runtime-CiKstLBL.js";import{T}from"./index-ByRjpJkx.js";import{P as S}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./Header-C4ns3adS.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-RzZosPvc.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./index-CK4JAWPB.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Emoji-37DYiqy7.js";import"./UserSelect-C_dihNXv.js";import"./UserItem-B0Lm5Uy4.js";import"./Checkbox-CDjsaAO6.js";import"./Modal-BfMZBOgd.js";import"./ContactDetail-f0-vKvCe.js";import"./Search-Lk8wQ1Ll.js";import"./useAddress-B7gFrhkG.js";import"./Empty-CK0D8RIw.js";import"./AudioMessage-nvljx91n.js";import"./MessageStatus-Q5VJSgQa.js";import"./UserProfile-BjPQF8r1.js";import"./MessageList-plN_fzYh.js";import"./ScrollList-CeMeqK6h.js";import"./Input-jxC5tNka.js";const e="zh",r={en:{prefix:"CSS class name prefix",className:"CSS class name",style:"CSS style",messageListProps:"Props for MessageList",messageInputProps:"Props for MessageInput",Thread:"Thread component is a container component that encapsulates the thread function. It is mainly used to display the thread and support creating and joining sub-conversations based on a message. "},zh:{prefix:"类名前缀",className:"类名",style:"样式",messageListProps:"MessageList 的 props",messageInputProps:"MessageInput 的 props",Thread:"Thread 组件是一个容器组件，可以根据一条消息创建一个子会话，封装了会话子区及其消息和输入的功能。子区的入口会显示在消息上，可以点击消息上的子区功能创建或者加入子区，也可以在Chat 组件的 Header 部分点击子区列表进入子区。"}},x=p=>a.jsx("div",{style:{height:"500px"},children:a.jsx(S,{initConfig:{appKey:"a#b"},children:a.jsx(T,{...p})})}),$={title:"Container/Thread",component:x,parameters:{docs:{description:{component:r[e].Thread}}},argTypes:{prefix:{control:"text",description:r[e].prefix,defaultValue:"cui"},className:{control:"text",description:r[e].className},style:{control:"object",description:r[e].style},messageListProps:{control:"object",description:r[e].messageListProps},messageInputProps:{control:"object",description:r[e].messageInputProps}}},i=p=>a.jsx(x,{...p}),s={render:i,args:{}},t={render:i,args:{}},o={render:i,args:{}};var n,m,c;s.parameters={...s.parameters,docs:{...(n=s.parameters)==null?void 0:n.docs,source:{originalSource:`{
  render: Template,
  args: {
    // 根据实际的Thread组件属性和方法设置默认参数
  }
}`,...(c=(m=s.parameters)==null?void 0:m.docs)==null?void 0:c.source}}};var d,l,u;t.parameters={...t.parameters,docs:{...(d=t.parameters)==null?void 0:d.docs,source:{originalSource:`{
  render: Template,
  args: {
    // Dark mode specific args
  }
}`,...(u=(l=t.parameters)==null?void 0:l.docs)==null?void 0:u.source}}};var g,h,f;o.parameters={...o.parameters,docs:{...(g=o.parameters)==null?void 0:g.docs,source:{originalSource:`{
  render: Template,
  args: {
    // Square mode specific args
  }
}`,...(f=(h=o.parameters)==null?void 0:h.docs)==null?void 0:f.source}}};const ee=["Default","Dark","Square"];export{t as Dark,s as Default,o as Square,ee as __namedExportsOrder,$ as default};
