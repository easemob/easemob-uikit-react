import{j as e}from"./jsx-runtime-CiKstLBL.js";import{N as i}from"./NetworkQuality-8bNuv49X.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";const I={title:"pure component/NetworkQuality",component:i,parameters:{layout:"centered"},argTypes:{level:{control:"select",options:[1,2,3,4,5,6],description:"网络质量等级"},size:{control:"select",options:["small","medium","large"],description:"组件大小"}}},s={args:{level:3,size:"medium"}},r={render:()=>e.jsxs("div",{style:{display:"flex",gap:"20px",alignItems:"center"},children:[e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:6}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"信号弱"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:3}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"信号中等"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:1}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"信号强"})]})]})},n={render:()=>e.jsxs("div",{style:{display:"flex",gap:"20px",alignItems:"center"},children:[e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:3,size:"small"}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"小号"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:3,size:"medium"}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"中号"})]}),e.jsxs("div",{style:{textAlign:"center"},children:[e.jsx(i,{level:3,size:"large"}),e.jsx("div",{style:{marginTop:"8px",fontSize:"12px"},children:"大号"})]})]})},t={args:{level:1,size:"medium"}},l={args:{level:3,size:"medium"}},a={args:{level:6,size:"medium"}};var o,d,p;s.parameters={...s.parameters,docs:{...(o=s.parameters)==null?void 0:o.docs,source:{originalSource:`{
  args: {
    level: 3,
    size: 'medium'
  }
}`,...(p=(d=s.parameters)==null?void 0:d.docs)==null?void 0:p.source}}};var c,m,x;r.parameters={...r.parameters,docs:{...(c=r.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: '20px',
    alignItems: 'center'
  }}>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={6} />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>信号弱</div>
      </div>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={3} />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>信号中等</div>
      </div>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={1} />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>信号强</div>
      </div>
    </div>
}`,...(x=(m=r.parameters)==null?void 0:m.docs)==null?void 0:x.source}}};var v,g,u;n.parameters={...n.parameters,docs:{...(v=n.parameters)==null?void 0:v.docs,source:{originalSource:`{
  render: () => <div style={{
    display: 'flex',
    gap: '20px',
    alignItems: 'center'
  }}>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={3} size="small" />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>小号</div>
      </div>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={3} size="medium" />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>中号</div>
      </div>
      <div style={{
      textAlign: 'center'
    }}>
        <NetworkQuality level={3} size="large" />
        <div style={{
        marginTop: '8px',
        fontSize: '12px'
      }}>大号</div>
      </div>
    </div>
}`,...(u=(g=n.parameters)==null?void 0:g.docs)==null?void 0:u.source}}};var y,f,z;t.parameters={...t.parameters,docs:{...(y=t.parameters)==null?void 0:y.docs,source:{originalSource:`{
  args: {
    level: 1,
    size: 'medium'
  }
}`,...(z=(f=t.parameters)==null?void 0:f.docs)==null?void 0:z.source}}};var S,j,h;l.parameters={...l.parameters,docs:{...(S=l.parameters)==null?void 0:S.docs,source:{originalSource:`{
  args: {
    level: 3,
    size: 'medium'
  }
}`,...(h=(j=l.parameters)==null?void 0:j.docs)==null?void 0:h.source}}};var T,A,k;a.parameters={...a.parameters,docs:{...(T=a.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    level: 6,
    size: 'medium'
  }
}`,...(k=(A=a.parameters)==null?void 0:A.docs)==null?void 0:k.source}}};const _=["Default","DifferentLevels","DifferentSizes","WeakSignal","MediumSignal","StrongSignal"];export{s as Default,r as DifferentLevels,n as DifferentSizes,l as MediumSignal,a as StrongSignal,t as WeakSignal,_ as __namedExportsOrder,I as default};
