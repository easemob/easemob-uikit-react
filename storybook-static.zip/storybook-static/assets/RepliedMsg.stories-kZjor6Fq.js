import{j as r}from"./jsx-runtime-CiKstLBL.js";import{P as p}from"./Provider-DijW63BH.js";import{R as m}from"./AudioMessage-nvljx91n.js";import"./index-CoXXcpNP.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";import"./useAddress-B7gFrhkG.js";import"./MessageStatus-Q5VJSgQa.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";const e="zh",t={en:{message:"message",prefixCls:"prefixCls",className:"className",style:"style",shape:"shape",direction:"direction"},zh:{message:"消息",prefixCls:"类名前缀",className:"类名",style:"样式",shape:"气泡形状",direction:"方向"}},I={title:"Module/RepliedMsg",component:m,argTypes:{prefixCls:{control:"text",description:t[e].prefixCls},className:{control:"text",description:t[e].className},style:{control:"object",description:t[e].style},shape:{control:"select",options:["round","square"],description:t[e].shape},direction:{control:"select",options:["ltr","rtl"],description:t[e].direction},message:{control:"object",description:t[e].message,table:{type:{summary:"BaseMessageType"},details:{summary:'new BaseMessageType({ id: "1189528432543795984", type: "txt", chatType: "singleChat", msg: "asd", to: "zd4", from: "zd2", ext: { em_at_list: [], msgQuote: { msgID: "1187658028808145668", msgPreview: "Start a video call", msgSender: "zd4", msgType: "txt" }, }, time: 1694523470608, onlineState: 3, })'}}}}},l=n=>r.jsx(p,{initConfig:{appKey:"a#b"},children:r.jsx(m,{...n})}),s={render:l,args:{message:{id:"1189528432543795984",type:"txt",chatType:"singleChat",msg:"asd",to:"zd4",from:"zd2",ext:{em_at_list:[],msgQuote:{msgID:"1187658028808145668",msgPreview:"Start a video call",msgSender:"zd4",msgType:"txt"}},time:1694523470608,onlineState:3}}};var o,i,a;s.parameters={...s.parameters,docs:{...(o=s.parameters)==null?void 0:o.docs,source:{originalSource:`{
  render: Template,
  args: {
    message: {
      id: '1189528432543795984',
      type: 'txt',
      chatType: 'singleChat',
      msg: 'asd',
      to: 'zd4',
      from: 'zd2',
      ext: {
        em_at_list: [],
        msgQuote: {
          msgID: '1187658028808145668',
          msgPreview: 'Start a video call',
          msgSender: 'zd4',
          msgType: 'txt'
        }
      },
      time: 1694523470608,
      onlineState: 3
    }
  }
}`,...(a=(i=s.parameters)==null?void 0:i.docs)==null?void 0:a.source}}};const Q=["Primary"];export{s as Primary,Q as __namedExportsOrder,I as default};
