import{j as r}from"./jsx-runtime-CiKstLBL.js";import{V as m}from"./AudioMessage-nvljx91n.js";import{P as u}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./MessageStatus-Q5VJSgQa.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./index-RzZosPvc.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";import"./useAddress-B7gFrhkG.js";const e="zh",t={en:{videoMessage:"Video Message",prefix:"css class name prefix",className:"css class name",style:"css style",bubbleClass:"bubble class",type:"type",videoProps:"video props"},zh:{videoMessage:"视频消息",prefix:"css 类名前缀",className:"css 类名",style:"css 样式",bubbleClass:"bubble 类名",type:"类型",videoProps:"video 标签属性"}},x={title:"Module/VideoMessage",component:m,argTypes:{videoMessage:{description:t[e].videoMessage,control:{type:"object"}},prefix:{description:t[e].prefix,control:{type:"text"}},className:{description:t[e].className,control:{type:"text"}},style:{description:t[e].style,control:{type:"object"}},bubbleClass:{description:t[e].bubbleClass,control:{type:"text"}},type:{description:t[e].type,control:{type:"select",options:["primary","secondly"]}},videoProps:{description:t[e].videoProps,control:{type:"object"}}}},d=p=>r.jsx(u,{initConfig:{appKey:"a#b"},children:r.jsx(m,{...p})}),s={render:d,args:{videoMessage:{bySelf:!0,status:"read",id:"1239518913788642904",type:"video",chatType:"singleChat",from:"zd2",to:"ljn",url:"https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",secret:"36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",thumb:"https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc&vframe=true",thumb_secret:"36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",filename:"9f6982b61c1d8c56a8e7497a4d6c5857.mov",length:0,file:{},file_length:4364210,filetype:"",accessToken:"YWMtIf-vkMAHEe6c2MuyWS0mOFzzvlQ7sUrSpVuQGlyIzFRFkCIQGcwR7bF7ZX4Zh6nOAwMAAAGNXlZjFTeeSAAhJwEadorA32-JBb5SxWmTBXO1T2_O0loXuNs0cysMhw",ext:{ease_chat_uikit_user_info:{nickname:"我的名字zd2",avatarURL:""}},time:1706162786531}}},a={render:d,args:{type:"secondly",direction:"ltr",videoMessage:{bySelf:!1,status:"received",id:"1239518913788642904",type:"video",chatType:"singleChat",from:"zd2",to:"ljn",url:"https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",secret:"36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",thumb:"https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc&vframe=true",thumb_secret:"36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc",filename:"9f6982b61c1d8c56a8e7497a4d6c5857.mov",length:0,file:{},file_length:4364210,filetype:"",accessToken:"YWMtIf-vkMAHEe6c2MuyWS0mOFzzvlQ7sUrSpVuQGlyIzFRFkCIQGcwR7bF7ZX4Zh6nOAwMAAAGNXlZjFTeeSAAhJwEadorA32-JBb5SxWmTBXO1T2_O0loXuNs0cysMhw",ext:{ease_chat_uikit_user_info:{nickname:"我的名字zd2",avatarURL:""}},time:1706162786531}}};var o,i,n;s.parameters={...s.parameters,docs:{...(o=s.parameters)==null?void 0:o.docs,source:{originalSource:`{
  render: Template,
  args: {
    videoMessage: {
      bySelf: true,
      status: 'read',
      id: '1239518913788642904',
      type: 'video',
      chatType: 'singleChat',
      from: 'zd2',
      to: 'ljn',
      url: 'https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      secret: '36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      thumb: 'https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc&vframe=true',
      thumb_secret: '36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      filename: '9f6982b61c1d8c56a8e7497a4d6c5857.mov',
      length: 0,
      file: {} as FileObj,
      file_length: 4364210,
      filetype: '',
      accessToken: 'YWMtIf-vkMAHEe6c2MuyWS0mOFzzvlQ7sUrSpVuQGlyIzFRFkCIQGcwR7bF7ZX4Zh6nOAwMAAAGNXlZjFTeeSAAhJwEadorA32-JBb5SxWmTBXO1T2_O0loXuNs0cysMhw',
      ext: {
        ease_chat_uikit_user_info: {
          nickname: '我的名字zd2',
          avatarURL: ''
        }
      },
      time: 1706162786531
    }
  }
}`,...(n=(i=s.parameters)==null?void 0:i.docs)==null?void 0:n.source}}};var c,l,b;a.parameters={...a.parameters,docs:{...(c=a.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: Template,
  args: {
    type: 'secondly',
    direction: 'ltr',
    videoMessage: {
      bySelf: false,
      status: 'received',
      id: '1239518913788642904',
      type: 'video',
      chatType: 'singleChat',
      from: 'zd2',
      to: 'ljn',
      url: 'https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      secret: '36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      thumb: 'https://a4-v2.easemob.com/easemob/easeim/chatfiles/dfab9460-bb47-11ee-9588-db947bb82d2a?em-redirect=true&share-secret=36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc&vframe=true',
      thumb_secret: '36wwoLtHEe6TWaXj8svlq2yZParnRbw-Oa-8DkviwYjuC1Uc',
      filename: '9f6982b61c1d8c56a8e7497a4d6c5857.mov',
      length: 0,
      file: {} as FileObj,
      file_length: 4364210,
      filetype: '',
      accessToken: 'YWMtIf-vkMAHEe6c2MuyWS0mOFzzvlQ7sUrSpVuQGlyIzFRFkCIQGcwR7bF7ZX4Zh6nOAwMAAAGNXlZjFTeeSAAhJwEadorA32-JBb5SxWmTBXO1T2_O0loXuNs0cysMhw',
      ext: {
        ease_chat_uikit_user_info: {
          nickname: '我的名字zd2',
          avatarURL: ''
        }
      },
      time: 1706162786531
    }
  }
}`,...(b=(l=a.parameters)==null?void 0:l.docs)==null?void 0:b.source}}};const z=["Primary","Secondly"];export{s as Primary,a as Secondly,z as __namedExportsOrder,x as default};
