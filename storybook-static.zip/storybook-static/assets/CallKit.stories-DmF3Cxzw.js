import{j as f}from"./jsx-runtime-CiKstLBL.js";import{r as h}from"./index-CoXXcpNP.js";import{C as re,l as Y}from"./PreviewLayout-SgBwVLK4.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./NetworkQuality-8bNuv49X.js";import"./index-DC6xhvrL.js";import"./index-S3NOQ7Fp.js";import"./Header-C4ns3adS.js";import"./index-RzZosPvc.js";import"./Tooltip-u8NvX5SI.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./index-ux5NTfpI.js";import"./UserSelect-C_dihNXv.js";import"./UserItem-B0Lm5Uy4.js";import"./Checkbox-CDjsaAO6.js";import"./Modal-BfMZBOgd.js";import"./ContactDetail-f0-vKvCe.js";import"./Search-Lk8wQ1Ll.js";import"./useAddress-B7gFrhkG.js";import"./index-DzFcepMq.js";import"./Empty-CK0D8RIw.js";const ne=o=>{const t=h.useRef(null),[b,ee]=h.useState(!1);return h.useEffect(()=>{const oe=setTimeout(()=>{if(t.current){if(o.videos&&o.videos.length>0){const te=o.callMode||(o.videos.length>2?"group":"video");t.current.showPreview(te),setTimeout(()=>{t.current&&t.current.startCall(o.videos)},100)}else t.current.showPreview(o.callMode||"video");ee(!0)}},300);return()=>clearTimeout(oe)},[o.videos,o.callMode]),f.jsxs("div",{style:{width:o.managedPosition===!1?"100%":"748px",height:o.managedPosition===!1?"600px":"523px",position:"relative"},children:[f.jsx(re,{ref:t,...o}),!b&&f.jsx("div",{style:{position:"absolute",top:0,left:0,right:0,bottom:0,background:"#1a1a1a",borderRadius:"8px",display:"flex",alignItems:"center",justifyContent:"center",color:"#fff",fontSize:"16px",zIndex:1e3},children:"Initializing CallKit Demo..."})]})},Ie={title:"Module/CallKit",component:ne,parameters:{layout:"centered",docs:{description:{component:"重构后的CallKit组件，支持多种布局模式和可调整大小功能"}}},tags:["autodocs"],argTypes:{className:{control:"text",description:"自定义CSS类名"},prefix:{control:"text",description:"CSS类名前缀"},maxVideos:{control:{type:"number",min:1,max:20},description:"最大显示视频数量"},aspectRatio:{control:{type:"range",min:.5,max:2,step:.1},description:"视频窗口宽高比"},gap:{control:{type:"range",min:0,max:20,step:2},description:"视频窗口间隙（像素）"},backgroundImage:{control:"text",description:"多人通话背景图片URL"},callMode:{control:"select",options:["video","audio","group"],description:"通话模式，如果不提供则从邀请信息推断"},showControls:{control:"boolean",description:"是否显示控制按钮"},muted:{control:"boolean",description:"是否静音"},cameraEnabled:{control:"boolean",description:"是否启用摄像头"},speakerEnabled:{control:"boolean",description:"是否启用扬声器"},enableRingtone:{control:"boolean",description:"是否启用铃声"},ringtoneVolume:{control:{type:"range",min:0,max:1,step:.1},description:"铃声音量，范围0-1"},ringtoneLoop:{control:"boolean",description:"是否循环播放铃声"},outgoingRingtoneSrc:{control:"text",description:"拨打电话铃声音频文件路径"},incomingRingtoneSrc:{control:"text",description:"接听电话铃声音频文件路径"},resizable:{control:"boolean",description:"是否可调整大小"},minWidth:{control:{type:"number",min:200,max:800,step:50},description:"最小宽度"},minHeight:{control:{type:"number",min:150,max:600,step:50},description:"最小高度"},maxWidth:{control:{type:"number",min:800,max:2e3,step:50},description:"最大宽度"},maxHeight:{control:{type:"number",min:600,max:1500,step:50},description:"最大高度"},draggable:{control:"boolean",description:"是否可拖动"},dragHandle:{control:"text",description:"CSS选择器，指定拖动手柄区域"},managedPosition:{control:"boolean",description:"是否使用内置位置管理"},isMinimized:{control:"boolean",description:"最小化状态"},acceptText:{control:"text",description:"接听按钮文本"},rejectText:{control:"text",description:"拒绝按钮文本"},showInvitationAvatar:{control:"boolean",description:"是否显示邀请者头像"},showInvitationTimer:{control:"boolean",description:"是否显示倒计时"},autoRejectTime:{control:{type:"number",min:10,max:120,step:5},description:"自动拒绝时间（秒）"},userSelectTitle:{control:"text",description:"用户选择弹窗标题（添加参与者时）"},initiateGroupCallTitle:{control:"text",description:"发起群组通话时的弹窗标题"},logLevel:{control:"select",options:["error","warn","info","debug","verbose"],description:"日志级别"},enableLogging:{control:"boolean",description:"是否启用日志输出"},logPrefix:{control:"text",description:"日志前缀"},speakingVolumeThreshold:{control:{type:"range",min:1,max:100,step:1},description:"说话指示器显示的音量阈值，范围1-100"},style:{control:!1,description:"自定义内联样式"},chatClient:{control:!1,description:"环信IM SDK实例"},groupMembers:{control:!1,description:"群组成员列表"},userInfoProvider:{control:!1,description:"用户信息提供器"},groupInfoProvider:{control:!1,description:"群组信息提供器"},customIcons:{control:!1,description:"自定义图标映射"},encoderConfig:{control:!1,description:"视频编码配置"},invitationCustomContent:{control:!1,description:"自定义邀请内容"},onVideoClick:{control:!1,description:"视频点击回调"},onMuteToggle:{control:!1,description:"静音切换回调"},onCameraToggle:{control:!1,description:"摄像头切换回调"},onSpeakerToggle:{control:!1,description:"扬声器切换回调"},onScreenShareToggle:{control:!1,description:"屏幕共享切换回调"},onHangup:{control:!1,description:"挂断回调"},onAddParticipant:{control:!1,description:"添加参与者回调"},onInvitationAccept:{control:!1,description:"接受邀请回调"},onInvitationReject:{control:!1,description:"拒绝邀请回调"},onCallStart:{control:!1,description:"通话开始回调"},onCallEnd:{control:!1,description:"通话结束回调"},onLayoutModeChange:{control:!1,description:"布局模式切换回调"},onResize:{control:!1,description:"大小调整回调"},onDragStart:{control:!1,description:"拖动开始回调"},onDrag:{control:!1,description:"拖动回调"},onDragEnd:{control:!1,description:"拖动结束回调"},onMinimizedChange:{control:!1,description:"最小化状态变化回调"},onCallError:{control:!1,description:"SDK错误回调"},onReceivedCall:{control:!1,description:"接收到通话回调"},onRemoteUserJoined:{control:!1,description:"远程用户加入回调"},onRemoteUserLeft:{control:!1,description:"远程用户离开回调"},onRtcEngineCreated:{control:!1,description:"RTC引擎创建回调"},onEndCallWithReason:{control:!1,description:"带原因的通话结束回调"}}},e=(o,t,b=!1)=>({id:o,nickname:t,isLocalVideo:b,muted:Math.random()>.7,avatar:`https://api.dicebear.com/7.x/avataaars/svg?seed=${t}`}),Z=[e("remote1","Alice"),e("local","我",!0)],r=[e("remote1","Alice"),e("remote2","Bob"),e("remote3","Charlie"),e("local","我",!0)],x=[e("remote1","Alice"),e("remote2","Bob"),e("remote3","Charlie"),e("remote4","David"),e("remote5","Eve"),e("remote6","Frank"),e("remote7","Grace"),e("local","我",!0)],ae=[...x,e("remote8","Henry"),e("remote9","Ivy"),e("remote10","Jack"),e("remote11","Kate")],n={args:{videos:r,aspectRatio:1,gap:8,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,managedPosition:!1}},a={args:{videos:r,callMode:"group",aspectRatio:1,gap:8,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,managedPosition:!1}},s={args:{videos:x,callMode:"group",aspectRatio:1,gap:6,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,managedPosition:!1}},i={args:{videos:ae,callMode:"group",aspectRatio:1,gap:4,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,managedPosition:!1}},l={args:{videos:[],aspectRatio:1,gap:8,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0}},c={args:{videos:Z,aspectRatio:1,gap:8,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0}},d={args:{videos:r,aspectRatio:1,gap:8,showControls:!1,muted:!1,cameraEnabled:!0,speakerEnabled:!0}},p={args:{videos:r,aspectRatio:1,gap:12,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,style:{border:"2px solid #1890ff",borderRadius:"12px",background:"linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)"}}},m={args:{videos:r,aspectRatio:1,gap:8,showControls:!0,resizable:!0,minWidth:400,minHeight:300,maxWidth:1200,maxHeight:800,muted:!1,cameraEnabled:!0,speakerEnabled:!0,onResize:(o,t)=>{Y(`组件大小已调整为: ${o}x${t}`)}},parameters:{docs:{description:{story:"启用可调整大小功能，鼠标移动到组件边缘（8px范围内）时显示resize光标，可以拖拽调整大小。支持设置最小和最大尺寸限制。"}}}},u={args:{videos:Z,callMode:"video",aspectRatio:16/9,gap:8,showControls:!0,resizable:!0,minWidth:480,minHeight:320,maxWidth:1920,maxHeight:1080,muted:!1,cameraEnabled:!0,speakerEnabled:!0,onResize:(o,t)=>{Y(`1v1模式组件大小已调整为: ${o}x${t}`)}},parameters:{docs:{description:{story:"1v1模式下的可调整大小功能，适合用于弹窗或浮动窗口场景。"}}}},g={args:{videos:x,callMode:"group",aspectRatio:16/9,gap:8,showControls:!0,muted:!1,cameraEnabled:!0,speakerEnabled:!0,managedPosition:!1},parameters:{docs:{description:{story:"主视频布局模式：点击任意视频窗口，该视频会变大显示在上方，其他视频变小显示在下方一排并支持滑动。点击返回按钮可切换回网格布局。"}}}};var v,C,E;n.parameters={...n.parameters,docs:{...(v=n.parameters)==null?void 0:v.docs,source:{originalSource:`{
  args: {
    videos: mockVideos4,
    aspectRatio: 1,
    gap: 8,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    // 添加这些属性来强制显示CallKit
    managedPosition: false // 不使用固定定位，适配Storybook
  }
}`,...(E=(C=n.parameters)==null?void 0:C.docs)==null?void 0:E.source}}};var R,k,y;a.parameters={...a.parameters,docs:{...(R=a.parameters)==null?void 0:R.docs,source:{originalSource:`{
  args: {
    videos: mockVideos4,
    callMode: 'group',
    // 明确指定为群组通话模式
    aspectRatio: 1,
    gap: 8,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    managedPosition: false
  }
}`,...(y=(k=a.parameters)==null?void 0:k.docs)==null?void 0:y.source}}};var w,M,S;s.parameters={...s.parameters,docs:{...(w=s.parameters)==null?void 0:w.docs,source:{originalSource:`{
  args: {
    videos: mockVideos8,
    callMode: 'group',
    // 明确指定为群组通话模式
    aspectRatio: 1,
    gap: 6,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    managedPosition: false
  }
}`,...(S=(M=s.parameters)==null?void 0:M.docs)==null?void 0:S.source}}};var P,V,z;i.parameters={...i.parameters,docs:{...(P=i.parameters)==null?void 0:P.docs,source:{originalSource:`{
  args: {
    videos: mockVideos12,
    callMode: 'group',
    // 明确指定为群组通话模式
    aspectRatio: 1,
    gap: 4,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    managedPosition: false
  }
}`,...(z=(V=i.parameters)==null?void 0:V.docs)==null?void 0:z.source}}};var T,I,D;l.parameters={...l.parameters,docs:{...(T=l.parameters)==null?void 0:T.docs,source:{originalSource:`{
  args: {
    videos: [],
    aspectRatio: 1,
    gap: 8,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true
  }
}`,...(D=(I=l.parameters)==null?void 0:I.docs)==null?void 0:D.source}}};var H,L,W;c.parameters={...c.parameters,docs:{...(H=c.parameters)==null?void 0:H.docs,source:{originalSource:`{
  args: {
    videos: mockVideos2,
    // 可以在控制面板中修改视频数量来测试自动布局
    aspectRatio: 1,
    gap: 8,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true
  }
}`,...(W=(L=c.parameters)==null?void 0:L.docs)==null?void 0:W.source}}};var K,j,$;d.parameters={...d.parameters,docs:{...(K=d.parameters)==null?void 0:K.docs,source:{originalSource:`{
  args: {
    videos: mockVideos4,
    aspectRatio: 1,
    gap: 8,
    showControls: false,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true
  }
}`,...($=(j=d.parameters)==null?void 0:j.docs)==null?void 0:$.source}}};var A,N,O;p.parameters={...p.parameters,docs:{...(A=p.parameters)==null?void 0:A.docs,source:{originalSource:`{
  args: {
    videos: mockVideos4,
    aspectRatio: 1,
    gap: 12,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    style: {
      border: '2px solid #1890ff',
      borderRadius: '12px',
      background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)'
    }
  }
}`,...(O=(N=p.parameters)==null?void 0:N.docs)==null?void 0:O.source}}};var U,B,G;m.parameters={...m.parameters,docs:{...(U=m.parameters)==null?void 0:U.docs,source:{originalSource:`{
  args: {
    videos: mockVideos4,
    aspectRatio: 1,
    gap: 8,
    showControls: true,
    resizable: true,
    minWidth: 400,
    minHeight: 300,
    maxWidth: 1200,
    maxHeight: 800,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    onResize: (width: number, height: number) => {
      logDebug(\`组件大小已调整为: \${width}x\${height}\`);
    }
  },
  parameters: {
    docs: {
      description: {
        story: '启用可调整大小功能，鼠标移动到组件边缘（8px范围内）时显示resize光标，可以拖拽调整大小。支持设置最小和最大尺寸限制。'
      }
    }
  }
}`,...(G=(B=m.parameters)==null?void 0:B.docs)==null?void 0:G.source}}};var J,_,F;u.parameters={...u.parameters,docs:{...(J=u.parameters)==null?void 0:J.docs,source:{originalSource:`{
  args: {
    videos: mockVideos2,
    callMode: 'video',
    // 明确指定为1v1视频通话模式
    aspectRatio: 16 / 9,
    gap: 8,
    showControls: true,
    resizable: true,
    minWidth: 480,
    minHeight: 320,
    maxWidth: 1920,
    maxHeight: 1080,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    onResize: (width: number, height: number) => {
      logDebug(\`1v1模式组件大小已调整为: \${width}x\${height}\`);
    }
  },
  parameters: {
    docs: {
      description: {
        story: '1v1模式下的可调整大小功能，适合用于弹窗或浮动窗口场景。'
      }
    }
  }
}`,...(F=(_=u.parameters)==null?void 0:_.docs)==null?void 0:F.source}}};var q,Q,X;g.parameters={...g.parameters,docs:{...(q=g.parameters)==null?void 0:q.docs,source:{originalSource:`{
  args: {
    videos: mockVideos8,
    callMode: 'group',
    // 明确指定为群组通话模式
    aspectRatio: 16 / 9,
    gap: 8,
    showControls: true,
    muted: false,
    cameraEnabled: true,
    speakerEnabled: true,
    managedPosition: false
  },
  parameters: {
    docs: {
      description: {
        story: '主视频布局模式：点击任意视频窗口，该视频会变大显示在上方，其他视频变小显示在下方一排并支持滑动。点击返回按钮可切换回网格布局。'
      }
    }
  }
}`,...(X=(Q=g.parameters)==null?void 0:Q.docs)==null?void 0:X.source}}};const De=["Default","MultiParty4","MultiParty8","MultiParty12","NoVideos","AutoLayout","NoControls","CustomStyle","ResizableMode","ResizableOneToOne","MainVideoLayout"];export{c as AutoLayout,p as CustomStyle,n as Default,g as MainVideoLayout,i as MultiParty12,a as MultiParty4,s as MultiParty8,d as NoControls,l as NoVideos,m as ResizableMode,u as ResizableOneToOne,De as __namedExportsOrder,Ie as default};
