import{j as s}from"./jsx-runtime-CiKstLBL.js";import{P as n}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";import"./useAddress-B7gFrhkG.js";const e="zh",t={en:{provider:"`UIKitProvider` is used to manage data. `UIKitProvider` does not render any UI, it is only used to provide a global context for other components, and it automatically listens to SDK events, passing data down to the component tree to drive component updates. Other components in UIKit must be wrapped by `UIKitProvider`.",initConfig:"Initial configuration for the provider",theme:"Theme configuration for the provider",children:"Child components to be wrapped by the provider",initConfig_appKey:"Application key for initialization",initConfig_userId:"User ID for initialization, if uikit internal automatic login is required, it is required to pass in",initConfig_token:"User token for initialization, if uikit internal automatic login is required, it is required to pass in",initConfig_password:"User password for initialization, if uikit internal automatic login is required, it is required to pass in",initConfig_translationTargetLanguage:"Translation target language, text message translation function uses",initConfig_useUserInfo:"Whether to use user information, default: true, if set to true, uikit internal will automatically get the user information of itself and other users, used to display the user's avatar and nickname, the user should call the SDK's setUserInfo method to set their own user information after login. If set to false, uikit internal will default to display the userId and default avatar, and you need to set the user information yourself.",initConfig_useReplacedMessageContents:"Set SDK whether to use replaced message contents, content review function uses",initConfig_maxMessages:"Maximum number of messages in a single conversation, exceeding which old messages will be discarded, and the old messages will be loaded out when scrolling to the top to load historical messages",initConfig_isFixedDeviceId:"Whether to fix the device ID",theme_primaryColor:"Primary color, 16-bit color value or hue value",theme_mode:"Theme mode, light or dark",theme_avatarShape:"Avatar shape, circle or square",theme_bubbleShape:"Bubble shape, round or square",theme_componentsShape:"Components shape, round or square",theme_ripple:"Whether to enable ripple effect",features:"Provider features configuration",features_chat:"Chat features configuration",features_chat_header:"Chat header features configuration",features_chat_header_threadList:"Chat header thread list features configuration",features_chat_header_moreAction:"Chat header more action features configuration",features_chat_header_clearMessage:"Chat header clear message features configuration",features_chat_header_deleteConversation:"Chat header delete conversation features configuration",features_chat_header_audioCall:"Chat header audio call features configuration",features_chat_header_videoCall:"Chat header video call features configuration",features_chat_header_pinMessage:"Chat header pin message features configuration",features_chat_message:"Chat message features configuration",features_chat_message_status:"Chat message status features configuration",features_chat_message_thread:"Chat message thread features configuration",features_chat_message_reaction:"Chat message reaction features configuration",features_chat_message_moreAction:"Chat message more action features configuration",features_chat_message_reply:"Chat message reply features configuration",features_chat_message_delete:"Chat message delete features configuration",features_chat_message_recall:"Chat message recall features configuration",features_chat_message_translate:"Chat message translate features configuration",features_chat_message_edit:"Chat message edit features configuration",features_chat_message_select:"Chat message select features configuration",features_chat_message_forward:"Chat message forward features configuration",features_chat_message_report:"Chat message report features configuration",features_chat_message_pin:"Chat message pin features configuration",features_chat_messageInput:"Chat message input features configuration",features_chat_messageInput_mention:"Chat message input mention features configuration",features_chat_messageInput_typing:"Chat message input typing features configuration",features_chat_messageInput_record:"Chat message input record features configuration",features_chat_messageInput_emoji:"Chat message input emoji features configuration",features_chat_messageInput_moreAction:"Chat message input more action features configuration",features_chat_messageInput_file:"Chat message input file features configuration",features_chat_messageInput_picture:"Chat message input picture features configuration",features_chat_messageInput_video:"Chat message input video features configuration",features_chat_messageInput_contactCard:"Chat message input contact card features configuration",features_conversationList:"Conversation list features configuration",features_conversationList_search:"Conversation list search features configuration",features_conversationList_item:"Conversation list item features configuration",features_conversationList_item_moreAction:"Conversation list item more action features configuration",features_conversationList_item_deleteConversation:"Conversation list item delete conversation features configuration",features_conversationList_item_pinConversation:"Conversation list item pin conversation features configuration",features_conversationList_item_muteConversation:"Conversation list item mute conversation features configuration",features_conversationList_item_presence:"Conversation list item presence features configuration",local:"config for localization",local_fallbackLng:"default language",local_lng:"current language",local_resources:"language resources",local_resources_key:'language resource key, such as "en" or "zh"',local_resources_translation:"language resource translation",local_resources_translation_key:'language resource translation key, such as "conversationTitle": "Conversation List"',reactionConfig:"config for message reaction",reactionConfig_map:"map for message reaction",reactionConfig_map_key:'message reaction key, such as "like" or "heart", value is the corresponding reaction image.',presenceMap:"config for user presence",presenceMap_key:'user presence key, such as "online" or "offline", value is the corresponding presence image.'},zh:{provider:"`UIKitProvider` 组件用来管理数据。 `UIKitProvider` 不渲染任何 UI, 只用来为其他组件提供全局的 context，它自动监听 SDK 事件, 在组件树中向下传递数据来驱动组件更新，UIKit 中其他组件必须用 `UIKitProvider` 包裹。",initConfig:"Provider 的初始配置",theme:"Provider 的主题配置",children:"由 Provider 包裹的子组件",initConfig_appKey:"应用的唯一标识",initConfig_userId:"用户id，如果需要uikit内部自动登录，则需要传入",initConfig_token:"用户token，如果需要uikit内部自动登录，则需要传入",initConfig_password:"用户密码，如果需要uikit内部自动登录，则需要传入",initConfig_translationTargetLanguage:"翻译目标语言，文本消息的翻译功能使用",initConfig_useUserInfo:"是否使用用户属性功能，默认：true，设置为true时，uikit内部会自动获取自己和其他用户的用户属性，用来展示用户的头像和昵称，用户在登录后应该调用SDK的setUserInfo方法设置自己的用户属性。如果设置为false，则uikit内部默认展示 userId 和默认头像，需要自己设置用户信息。",initConfig_useReplacedMessageContents:"设置SDK是否使用替换消息内容, 内容审核功能使用。",initConfig_maxMessages:"单个会话缓存的最大消息数，超过后会丢弃旧消息，在滚动到顶部加载历史消息时还会加载出来",initConfig_isFixedDeviceId:"是否固定设备id",theme_primaryColor:"主题颜色，16进制颜色值或者Hue值",theme_mode:"主题模式，light 或者 dark",theme_avatarShape:"头像形状，circle 或者 square",theme_bubbleShape:"气泡形状，round 或者 square",theme_componentsShape:"组件形状，round 或者 square",theme_ripple:"是否启用涟漪效果",features:"Provider 的功能配置",features_chat:"聊天功能配置",features_chat_header:"聊天头部功能配置",features_chat_header_threadList:"聊天头部子区列表功能配置",features_chat_header_moreAction:"聊天头部更多操作功能配置",features_chat_header_clearMessage:"聊天头部清除消息功能配置",features_chat_header_deleteConversation:"聊天头部删除会话功能配置",features_chat_header_audioCall:"聊天头部语音通话功能配置",features_chat_header_videoCall:"聊天头部视频通话功能配置",features_chat_header_pinMessage:"聊天头部置顶消息功能配置",features_chat_message:"聊天消息功能配置",features_chat_message_status:"聊天消息状态功能配置",features_chat_message_thread:"聊天消息子区功能配置",features_chat_message_reaction:"聊天消息表情回复功能配置",features_chat_message_moreAction:"聊天消息更多操作功能配置",features_chat_message_reply:"聊天消息回复功能配置",features_chat_message_delete:"聊天消息删除功能配置",features_chat_message_recall:"聊天消息撤回功能配置",features_chat_message_translate:"聊天消息翻译功能配置",features_chat_message_edit:"聊天消息编辑功能配置",features_chat_message_select:"聊天消息选择功能配置",features_chat_message_forward:"聊天消息单条转发功能配置",features_chat_message_report:"聊天消息举报功能配置",features_chat_message_pin:"聊天消息置顶功能配置",features_chat_messageInput:"聊天消息输入框功能配置",features_chat_messageInput_mention:"聊天消息输入框@功能配置",features_chat_messageInput_typing:"聊天消息输入框输入状态功能配置",features_chat_messageInput_record:"聊天消息输入框录音功能配置",features_chat_messageInput_emoji:"聊天消息输入框表情功能配置",features_chat_messageInput_moreAction:"聊天消息输入框更多操作功能配置",features_chat_messageInput_file:"聊天消息输入框文件功能配置",features_chat_messageInput_picture:"聊天消息输入框图片功能配置",features_chat_messageInput_video:"聊天消息输入框视频功能配置",features_chat_messageInput_contactCard:"聊天消息输入框联系人卡片功能配置",features_conversationList:"会话列表功能配置",features_conversationList_search:"会话列表搜索功能配置",features_conversationList_item:"会话列表会话项功能配置",features_conversationList_item_moreAction:"会话列表会话项更多操作功能配置",features_conversationList_item_deleteConversation:"会话列表会话项删除会话功能配置",features_conversationList_item_pinConversation:"会话列表会话项置顶会话功能配置",features_conversationList_item_muteConversation:"会话列表会话项免打扰功能配置",features_conversationList_item_presence:"会话列表会话项在线状态功能配置",local:"Provider 的本地化配置",local_fallbackLng:"默认语言",local_lng:"当前语言",local_resources:"语言资源",local_resources_key:'语言资源键，例如 "en" 或 "zh"',local_resources_translation:"语言资源翻译",local_resources_translation_key:'语言资源翻译键, 例如 "conversationTitle": "会话列表"',reactionConfig:"消息表情回复功能的表情配置",reactionConfig_map:"消息表情回复功能的表情映射",reactionConfig_map_key:'消息表情回复功能的表情键，例如 "like" 或 "heart"，值为对应的表情图片。',presenceMap:"用户在线状态的自定义配置",presenceMap_key:'用户在线状态键，例如 "online" 或 "offline"，值为对应的在线状态图片。'}},k={title:"Container/UIKitProvider",component:n,parameters:{docs:{description:{component:t[e].provider}}},argTypes:{initConfig:{control:"object",description:t[e].initConfig,table:{type:{summary:"object",detail:`{
    appKey: string; // ${t[e].initConfig_appKey}
    userId?: string; // ${t[e].initConfig_userId}
    token?: string; // ${t[e].initConfig_token}
    password?: string; // ${t[e].initConfig_password}
    translationTargetLanguage?: string; // ${t[e].initConfig_translationTargetLanguage}
    useUserInfo?: boolean; // ${t[e].initConfig_useUserInfo}
    useReplacedMessageContents?: boolean; // ${t[e].initConfig_useReplacedMessageContents}
    maxMessages?: number; // ${t[e].initConfig_maxMessages}
    isFixedDeviceId?: boolean; // ${t[e].initConfig_isFixedDeviceId}
}`}}},theme:{control:"object",description:t[e].theme,table:{type:{summary:"object",detail:`{
    primaryColor?: string | number; // ${t[e].theme_primaryColor}
    mode?: 'light' | 'dark'; // ${t[e].theme_mode}
    avatarShape?: 'circle' | 'square'; // ${t[e].theme_avatarShape}
    bubbleShape?: 'round' | 'square'; // ${t[e].theme_bubbleShape}
    componentsShape?: 'round' | 'square'; // ${t[e].theme_componentsShape}
    ripple?: boolean; // ${t[e].theme_ripple}
}`}}},features:{control:"object",description:t[e].features,table:{type:{summary:"object",detail:`{
chat?: { // ${t[e].features_chat}
      header?: { // ${t[e].features_chat_header}
        threadList: boolean; // ${t[e].features_chat_header_threadList}
        moreAction?: boolean; // ${t[e].features_chat_header_moreAction}
        clearMessage?: boolean; // ${t[e].features_chat_header_clearMessage}
        deleteConversation?: boolean; // ${t[e].features_chat_header_deleteConversation}
        audioCall?: boolean; // ${t[e].features_chat_header_audioCall}
        videoCall?: boolean; // ${t[e].features_chat_header_videoCall}
        pinMessage?: boolean; // ${t[e].features_chat_header_pinMessage}
      };
      message?: { // ${t[e].features_chat_message}
        status?: boolean; // ${t[e].features_chat_message_status}
        thread?: boolean; // ${t[e].features_chat_message_thread}
        reaction?: boolean; // ${t[e].features_chat_message_reaction}
        moreAction?: boolean; // ${t[e].features_chat_message_moreAction}
        reply?: boolean; // ${t[e].features_chat_message_reply}
        delete?: boolean; // ${t[e].features_chat_message_delete}
        recall?: boolean; // ${t[e].features_chat_message_recall}      
        translate?: boolean; // ${t[e].features_chat_message_translate}
        edit?: boolean; // ${t[e].features_chat_message_edit}
        select?: boolean; // ${t[e].features_chat_message_select}
        forward?: boolean; // ${t[e].features_chat_message_forward}
        report?: boolean; // ${t[e].features_chat_message_report}
        pin?: boolean; // ${t[e].features_chat_message_pin}
      };
      messageInput?: { // ${t[e].features_chat_messageInput}
        mention?: boolean; // ${t[e].features_chat_messageInput_mention}
        typing?: boolean; // ${t[e].features_chat_messageInput_typing}
        record?: boolean; // ${t[e].features_chat_messageInput_record}
        emoji?: boolean; // ${t[e].features_chat_messageInput_emoji}
        moreAction?: boolean; // ${t[e].features_chat_messageInput_moreAction}
        file?: boolean; // ${t[e].features_chat_messageInput_file}
        picture?: boolean; // ${t[e].features_chat_messageInput_picture}
        video?: boolean; // ${t[e].features_chat_messageInput_video}
        contactCard?: boolean; // ${t[e].features_chat_messageInput_contactCard}
      };
    };
    conversationList?: { // ${t[e].features_conversationList}
      search?: boolean; // ${t[e].features_conversationList_search}
      item?: { // ${t[e].features_conversationList_item}
        moreAction?: boolean; // ${t[e].features_conversationList_item_moreAction}
        deleteConversation?: boolean; // ${t[e].features_conversationList_item_deleteConversation}
        pinConversation?: boolean; // ${t[e].features_conversationList_item_pinConversation}
        muteConversation?: boolean; // ${t[e].features_conversationList_item_muteConversation}
      };
    };
}`}}},local:{control:"object",description:t[e].local,table:{type:{summary:"object",detail:`{
    fallbackLng?: string; // ${t[e].local_fallbackLng}
    lng?: string; // ${t[e].local_lng} 
    resources?: { // ${t[e].local_resources}
      [key: string]: { // ${t[e].local_resources_key}
        translation: { // ${t[e].local_resources_translation}
          [key: string]: string; // ${t[e].local_resources_translation_key}
        };
      };
    };
}`}}},reactionConfig:{control:"object",description:t[e].reactionConfig,table:{type:{summary:"object",detail:`{
    map: { // ${t[e].reactionConfig_map}
      [key: string]: HTMLImageElement; // ${t[e].reactionConfig_map_key}
    };
}`}}},presenceMap:{control:"object",description:t[e].presenceMap,table:{type:{summary:"object",detail:`{
    [key: string]: string | HTMLImageElement; // ${t[e].presenceMap_key}
}`}}},children:{control:"text",description:t[e].children}}},c=_=>s.jsx(n,{..._,children:s.jsx("div",{children:"UIKitProvider"})}),a={render:c,args:{initConfig:{appKey:"a#b"},theme:{mode:"light"},children:"This is a child component wrapped by Provider."}};var r,o,i;a.parameters={...a.parameters,docs:{...(r=a.parameters)==null?void 0:r.docs,source:{originalSource:`{
  render: Template,
  args: {
    initConfig: {
      appKey: 'a#b'
    },
    theme: {
      mode: 'light'
    },
    children: 'This is a child component wrapped by Provider.'
  }
}`,...(i=(o=a.parameters)==null?void 0:o.docs)==null?void 0:i.source}}};const L=["Default"];export{a as Default,L as __namedExportsOrder,k as default};
