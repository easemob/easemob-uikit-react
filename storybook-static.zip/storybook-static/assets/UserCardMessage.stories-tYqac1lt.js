import{j as o}from"./jsx-runtime-CiKstLBL.js";import{U as l}from"./AudioMessage-nvljx91n.js";import{P as y}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./MessageStatus-Q5VJSgQa.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./index-RzZosPvc.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";import"./useAddress-B7gFrhkG.js";const e="zh",s={en:{customMessage:"Custom message",prefix:"css class name prefix",className:"css class name",style:"css style",onClick:"Callback when clicking",bubbleClass:"bubble class name",onUserIdCopied:"Callback when copying user ID",type:"type"},zh:{customMessage:"自定义消息",prefix:"类名前缀",className:"类名",style:"样式",onClick:"点击回调",bubbleClass:"气泡类名",onUserIdCopied:"用户ID复制回调",type:"类型"}},O={title:"Module/UserCardMessage",component:l,argTypes:{customMessage:{description:s[e].customMessage,control:{type:"object"},table:{type:{summary:"CustomMessageType"}}},prefix:{description:s[e].prefix,control:{type:"text"}},style:{description:s[e].style,control:{type:"object"}},className:{description:s[e].className,control:{type:"text"}},type:{description:s[e].type,control:{type:"select",options:["primary","secondly"]}},onClick:{description:s[e].onClick},bubbleClass:{description:s[e].bubbleClass,control:{type:"text"}},onUserIdCopied:{description:s[e].onUserIdCopied}}},d=u=>o.jsx(y,{initConfig:{appKey:"a#b"},children:o.jsx(l,{...u})}),t={render:d,args:{customMessage:{type:"custom",id:"1234567890",to:"userId",chatType:"singleChat",bySelf:!0,from:"myUserId",time:Date.now(),status:"sent",customEvent:"userCard",customExts:{uid:"zd2",nickname:"Tom",avatar:"https://accktvpic.oss-cn-beijing.aliyuncs.com/pic/sample_avatar/sample_avatar_1.png"}}}},a={render:d,args:{type:"secondly",direction:"ltr",customMessage:{type:"custom",id:"1234567890",to:"userId",chatType:"singleChat",bySelf:!1,from:"myUserId",time:Date.now(),status:"sent",customEvent:"userCard",customExts:{uid:"zd2",nickname:"Tom",avatar:"https://accktvpic.oss-cn-beijing.aliyuncs.com/pic/sample_avatar/sample_avatar_1.png"}}}};var r,n,c;t.parameters={...t.parameters,docs:{...(r=t.parameters)==null?void 0:r.docs,source:{originalSource:`{
  render: Template,
  args: {
    customMessage: {
      type: 'custom',
      id: '1234567890',
      to: 'userId',
      chatType: 'singleChat',
      bySelf: true,
      from: 'myUserId',
      time: Date.now(),
      status: 'sent',
      customEvent: 'userCard',
      customExts: {
        uid: 'zd2',
        nickname: 'Tom',
        avatar: 'https://accktvpic.oss-cn-beijing.aliyuncs.com/pic/sample_avatar/sample_avatar_1.png'
      }
    }
  }
}`,...(c=(n=t.parameters)==null?void 0:n.docs)==null?void 0:c.source}}};var i,p,m;a.parameters={...a.parameters,docs:{...(i=a.parameters)==null?void 0:i.docs,source:{originalSource:`{
  render: Template,
  args: {
    type: 'secondly',
    direction: 'ltr',
    customMessage: {
      type: 'custom',
      id: '1234567890',
      to: 'userId',
      chatType: 'singleChat',
      bySelf: false,
      from: 'myUserId',
      time: Date.now(),
      status: 'sent',
      customEvent: 'userCard',
      customExts: {
        uid: 'zd2',
        nickname: 'Tom',
        avatar: 'https://accktvpic.oss-cn-beijing.aliyuncs.com/pic/sample_avatar/sample_avatar_1.png'
      }
    }
  }
}`,...(m=(p=a.parameters)==null?void 0:p.docs)==null?void 0:m.source}}};const R=["Primary","Secondly"];export{t as Primary,a as Secondly,R as __namedExportsOrder,O as default};
