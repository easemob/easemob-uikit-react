import{I as c}from"./AudioMessage-nvljx91n.js";import"./jsx-runtime-CiKstLBL.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./MessageStatus-Q5VJSgQa.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./index-RzZosPvc.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";const e="zh",t={en:{imageMessage:"Image message object",type:"Type of message",file_length:"Length of the file",file:"File object",url:"URL of the image",id:"Unique identifier",to:"Recipient ID",chatType:"Type of chat",bySelf:"Sent by self",from:"Sender ID",time:"Timestamp",status:"Status of the message",prefix:"Prefix for CSS classes",style:"CSS style",className:"CSS class name",bubbleClass:"Bubble CSS class name",onClickImage:"Callback for image click",imgProps:"Additional image properties"},zh:{imageMessage:"图片消息对象",type:"消息类型",file_length:"文件长度",file:"文件对象",url:"图片的URL",id:"唯一标识符",to:"接收者ID",chatType:"聊天类型",bySelf:"是否自己发送",from:"发送者ID",time:"时间戳",status:"消息状态",prefix:"CSS 类名前缀",style:"CSS 样式",className:"CSS 类名",bubbleClass:"气泡 CSS 类名",onClickImage:"图片点击的回调",imgProps:"附加的图片属性"}},P={title:"Module/ImageMessage",component:c,argTypes:{imageMessage:{control:"object",description:t[e].imageMessage},prefix:{control:"text",description:t[e].prefix},style:{control:"object",description:t[e].style},className:{control:"text",description:t[e].className},bubbleClass:{control:"text",description:t[e].bubbleClass},onClickImage:{type:"function",description:t[e].onClickImage},imgProps:{control:"object",description:t[e].imgProps}}},s={args:{imageMessage:{type:"img",file_length:1024,file:{url:"https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF",filename:"test.txt",filetype:"txt",data:{}},url:"https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF",id:"1234567890",to:"userId",chatType:"singleChat",bySelf:!0,from:"myUserId",time:Date.now(),status:"sent"},className:"custom-class",bubbleClass:"bubble-class",nickName:"John Doe"}},a={args:{type:"secondly",direction:"ltr",imageMessage:{type:"img",file_length:1024,file:{url:"https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF",filename:"test.txt",filetype:"txt",data:{}},url:"https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF",id:"1234567890",to:"userId",chatType:"singleChat",bySelf:!0,from:"myUserId",time:Date.now(),status:"sent"},className:"custom-class",bubbleClass:"bubble-class",nickName:"Jane Doe"}};var i,o,n;s.parameters={...s.parameters,docs:{...(i=s.parameters)==null?void 0:i.docs,source:{originalSource:`{
  args: {
    imageMessage: {
      type: 'img',
      file_length: 1024,
      file: {
        url: 'https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF',
        filename: 'test.txt',
        filetype: 'txt',
        data: {} as File
      },
      url: 'https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF',
      id: '1234567890',
      to: 'userId',
      chatType: 'singleChat',
      bySelf: true,
      from: 'myUserId',
      time: Date.now(),
      status: 'sent'
    },
    className: 'custom-class',
    bubbleClass: 'bubble-class',
    nickName: 'John Doe'
  }
}`,...(n=(o=s.parameters)==null?void 0:o.docs)==null?void 0:n.source}}};var l,r,m;a.parameters={...a.parameters,docs:{...(l=a.parameters)==null?void 0:l.docs,source:{originalSource:`{
  args: {
    type: 'secondly',
    direction: 'ltr',
    imageMessage: {
      type: 'img',
      file_length: 1024,
      file: {
        url: 'https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF',
        filename: 'test.txt',
        filetype: 'txt',
        data: {} as File
      },
      url: 'https://t7.baidu.com/it/u=848096684,3883475370&fm=193&f=GIF',
      id: '1234567890',
      to: 'userId',
      chatType: 'singleChat',
      bySelf: true,
      from: 'myUserId',
      time: Date.now(),
      status: 'sent'
    },
    className: 'custom-class',
    bubbleClass: 'bubble-class',
    nickName: 'Jane Doe'
  }
}`,...(m=(r=a.parameters)==null?void 0:r.docs)==null?void 0:m.source}}};const U=["Primary","Secondly"];export{s as Primary,a as Secondly,U as __namedExportsOrder,P as default};
