import{j as r}from"./jsx-runtime-CiKstLBL.js";import{P as h}from"./Provider-DijW63BH.js";import{U as i}from"./UserSelect-C_dihNXv.js";import{B as l}from"./Button-DkmWd_yB.js";import"./index-CoXXcpNP.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";import"./useAddress-B7gFrhkG.js";import"./UserItem-B0Lm5Uy4.js";import"./Checkbox-CDjsaAO6.js";import"./Ripple-C_wTLl8Y.js";import"./Modal-BfMZBOgd.js";import"./ContactDetail-f0-vKvCe.js";import"./Search-Lk8wQ1Ll.js";import"./Header-C4ns3adS.js";import"./Empty-CK0D8RIw.js";const e="zh",t={en:{prefix:"css class name prefix",className:"css class name",style:"css style",onUserSelect:"Callback when selecting user",enableMultipleSelection:"Whether to enable multiple selection",selectedPanelHeader:"Selected panel header",selectedPanelFooter:"Selected panel footer",users:"User list",checkedUsers:"Checked user list",disableUserIds:"Disabled user ID list",disabled:"Disabled",searchPlaceholder:"Search placeholder",onConfirm:"Confirm callback"},zh:{prefix:"css 类名前缀",className:"css 类名",style:"css 样式",onUserSelect:"用户选择回调",enableMultipleSelection:"是否启用多选",selectedPanelHeader:"已选用户面板头部",selectedPanelFooter:"已选用户面板底部",users:"用户列表",checkedUsers:"已选用户列表",disableUserIds:"禁用用户ID列表",disabled:"是否禁用",searchPlaceholder:"搜索框占位符",onConfirm:"确认回调"}},_={title:"Module/UserSelect",component:i,argTypes:{prefix:{description:t[e].prefix,control:{type:"text"},type:"string"},className:{description:t[e].className,control:{type:"text"},type:"string"},style:{description:t[e].style,control:{type:"object"}},enableMultipleSelection:{description:t[e].enableMultipleSelection,control:{type:"boolean"},type:"boolean"},selectedPanelHeader:{description:t[e].selectedPanelHeader,control:{type:"object"}},selectedPanelFooter:{description:t[e].selectedPanelFooter,control:{type:"object"}},users:{description:t[e].users,control:{type:"object"}},checkedUsers:{description:t[e].checkedUsers,control:{type:"object"}},disableUserIds:{description:t[e].disableUserIds,control:{type:"object"}},disabled:{description:t[e].disabled,control:{type:"boolean"},type:"boolean"},searchPlaceholder:{description:t[e].searchPlaceholder,control:{type:"text"},type:"string"},onConfirm:{description:t[e].onConfirm}}},b=n=>r.jsx(i,{...n,closable:!0,enableMultipleSelection:!0}),y=n=>r.jsx(h,{initConfig:{appKey:"z#b"},theme:{mode:"dark"},children:r.jsx("div",{style:{background:"#171a1c"},children:r.jsx(i,{...n,closable:!0,enableMultipleSelection:!0})})}),s={render:b,args:{enableMultipleSelection:!0,closable:!0,open:!0,title:"Select Users",users:[{userId:"zd1",nickname:"Zhao Yun"},{userId:"zd2",nickname:"Guan Yu"}],checkedUsers:[{userId:"zd1",nickname:"Zhao Yun"}],selectedPanelFooter:r.jsxs("div",{children:[r.jsx(l,{type:"primary",style:{marginRight:"20px",width:"80px"},children:"Confirm"}),r.jsx(l,{style:{width:"80px"},children:"Cancel"})]})}},o={render:y,args:{enableMultipleSelection:!0,closable:!0,open:!0,title:"Select Users",users:[{userId:"zd1",nickname:"Zhao Yun"},{userId:"zd2",nickname:"Guan Yu"}],checkedUsers:[{userId:"zd1",nickname:"Zhao Yun"}],selectedPanelFooter:r.jsxs("div",{children:[r.jsx(l,{type:"primary",style:{marginRight:"20px",width:"80px"},children:"Confirm"}),r.jsx(l,{style:{width:"80px"},children:"Cancel"})]})}};var c,a,d;s.parameters={...s.parameters,docs:{...(c=s.parameters)==null?void 0:c.docs,source:{originalSource:`{
  render: Template,
  args: {
    enableMultipleSelection: true,
    closable: true,
    open: true,
    title: 'Select Users',
    users: [{
      userId: 'zd1',
      nickname: 'Zhao Yun'
    }, {
      userId: 'zd2',
      nickname: 'Guan Yu'
    }],
    checkedUsers: [{
      userId: 'zd1',
      nickname: 'Zhao Yun'
    }],
    selectedPanelFooter: <div>
        <Button type="primary" style={{
        marginRight: '20px',
        width: '80px'
      }}>
          Confirm
        </Button>
        <Button style={{
        width: '80px'
      }}>Cancel</Button>
      </div>
  }
}`,...(d=(a=s.parameters)==null?void 0:a.docs)==null?void 0:d.source}}};var p,u,m;o.parameters={...o.parameters,docs:{...(p=o.parameters)==null?void 0:p.docs,source:{originalSource:`{
  render: DarkTemplate,
  args: {
    enableMultipleSelection: true,
    closable: true,
    open: true,
    title: 'Select Users',
    users: [{
      userId: 'zd1',
      nickname: 'Zhao Yun'
    }, {
      userId: 'zd2',
      nickname: 'Guan Yu'
    }],
    checkedUsers: [{
      userId: 'zd1',
      nickname: 'Zhao Yun'
    }],
    selectedPanelFooter: <div>
        <Button type="primary" style={{
        marginRight: '20px',
        width: '80px'
      }}>
          Confirm
        </Button>
        <Button style={{
        width: '80px'
      }}>Cancel</Button>
      </div>
  }
}`,...(m=(u=o.parameters)==null?void 0:u.docs)==null?void 0:m.source}}};const E=["Default","Dark"];export{o as Dark,s as Default,E as __namedExportsOrder,_ as default};
