import{R as o}from"./index-CoXXcpNP.js";const n=(t,e)=>e||(t?`cui-${t}`:"cui"),r=o.createContext({getPrefixCls:n});r.Consumer;r.Provider;export{r as C};
