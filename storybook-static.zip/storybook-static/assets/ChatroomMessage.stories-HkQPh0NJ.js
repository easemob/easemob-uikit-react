import{j as r}from"./jsx-runtime-CiKstLBL.js";import{C as g}from"./ChatroomMessage-BmigdVdJ.js";import{P as u}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./index-RzZosPvc.js";import"./rootContext-c98KtOd0.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./reactNode-CrwpwiaA.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Icon-CScj7eB3.js";import"./AudioMessage-nvljx91n.js";import"./MessageStatus-Q5VJSgQa.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";import"./useAddress-B7gFrhkG.js";const e="zh",t={en:{chatroomMessage:"Chatroom message component",prefix:"Prefix",className:"Class name",style:"Style",message:"The message object",targetLanguage:"The target language of translation",onReport:"The callback function for reporting, the parameter is the message object, you need to implement the pop-up report dialog by yourself"},zh:{chatroomMessage:"聊天室消息组件",prefix:"组件类名前缀",className:"组件类名",style:"组件样式",message:"消息对象",targetLanguage:"翻译的目标语言",onReport:"举报的回调函数, 参数为消息对象, 需要自己实现弹出举报的弹框"}},A={title:"Module/ChatroomMessage",component:g,argTypes:{prefix:{control:"text",type:"string",description:t[e].prefix},className:{control:"text",type:"string",description:t[e].className},style:{control:"object",description:t[e].style},message:{control:"object",description:t[e].message},targetLanguage:{control:"text",description:t[e].targetLanguage},onReport:{action:"report",description:t[e].onReport}}},l=f=>r.jsx(u,{initConfig:{appKey:"a#b"},children:r.jsx(g,{...f})}),o={render:l,args:{message:{type:"txt",msg:"hello",id:"1234567890",to:"chatroomId",chatType:"chatRoom",from:"Leo",time:Date.now()}}},a={render:l,args:{message:{id:"1231026004235920980",type:"custom",chatType:"chatRoom",from:"pev4pyzbwnutbp7a",to:"230164666580997",customEvent:"CHATROOMUIKITGIFT",params:{},customExts:{chatroom_uikit_gift:'{"giftId":"2665752a-e273-427c-ac5a-4b2a9c82b255","giftIcon":"https://fullapp.oss-cn-beijing.aliyuncs.com/uikit/pictures/gift/AUIKitGift1.png","giftName":"Heart","giftPrice":"1"}'},ext:{chatroom_uikit_userInfo:{userId:"pev4pyzbwnutbp7a",nickname:"Leo",avatarURL:"https://a1.easemob.com/easemob/chatroom-uikit/chatfiles/a27bd9a0-79f8-11ee-8f83-551faec94303",gender:1}},time:1704185376943,onlineState:1,priority:"normal",broadcast:!1}}};var s,i,m;o.parameters={...o.parameters,docs:{...(s=o.parameters)==null?void 0:s.docs,source:{originalSource:`{
  render: Template,
  args: {
    message: {
      type: 'txt',
      msg: 'hello',
      id: '1234567890',
      to: 'chatroomId',
      chatType: 'chatRoom',
      // bySelf: true,
      from: 'Leo',
      time: Date.now()
      // status: 'sent',
    }
  }
}`,...(m=(i=o.parameters)==null?void 0:i.docs)==null?void 0:m.source}}};var n,p,c;a.parameters={...a.parameters,docs:{...(n=a.parameters)==null?void 0:n.docs,source:{originalSource:`{
  render: Template,
  args: {
    message: {
      id: '1231026004235920980',
      type: 'custom',
      chatType: 'chatRoom',
      from: 'pev4pyzbwnutbp7a',
      to: '230164666580997',
      customEvent: 'CHATROOMUIKITGIFT',
      params: {},
      customExts: {
        chatroom_uikit_gift: '{"giftId":"2665752a-e273-427c-ac5a-4b2a9c82b255","giftIcon":"https://fullapp.oss-cn-beijing.aliyuncs.com/uikit/pictures/gift/AUIKitGift1.png","giftName":"Heart","giftPrice":"1"}'
      },
      ext: {
        chatroom_uikit_userInfo: {
          userId: 'pev4pyzbwnutbp7a',
          nickname: 'Leo',
          avatarURL: 'https://a1.easemob.com/easemob/chatroom-uikit/chatfiles/a27bd9a0-79f8-11ee-8f83-551faec94303',
          gender: 1
        }
      },
      time: 1704185376943,
      onlineState: 1,
      priority: 'normal',
      broadcast: false
      // bySelf: false,
    }
  }
}`,...(c=(p=a.parameters)==null?void 0:p.docs)==null?void 0:c.source}}};const G=["textMessage","giftMessage"];export{G as __namedExportsOrder,A as default,a as giftMessage,o as textMessage};
