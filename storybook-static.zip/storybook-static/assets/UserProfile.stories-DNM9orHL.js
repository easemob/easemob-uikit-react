import{j as o}from"./jsx-runtime-CiKstLBL.js";import{P as u}from"./Provider-DijW63BH.js";import{U as d}from"./UserProfile-BjPQF8r1.js";import"./index-CoXXcpNP.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";import"./useAddress-B7gFrhkG.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";const r="zh",e={en:{prefix:"css class name prefix",className:"css class name",style:"css style",userId:"user ID"},zh:{prefix:"css 类名前缀",className:"css 类名",style:"css 样式",userId:"用户ID"}},S={title:"Module/UserProfile",component:d,argTypes:{prefix:{description:e[r].prefix,control:{type:"text"},type:"string"},className:{description:e[r].className,control:{type:"text"},type:"string"},style:{description:e[r].style,control:{type:"object"}},userId:{description:e[r].userId,control:{type:"text"},type:"string"}}},y=l=>o.jsx(u,{initConfig:{appKey:"z#b"},theme:{mode:"dark"},children:o.jsx("div",{style:{background:"#171a1c"},children:o.jsx(d,{...l})})}),s={args:{userId:"henry"}},t={render:y,args:{userId:"tom"}};var a,i,p;s.parameters={...s.parameters,docs:{...(a=s.parameters)==null?void 0:a.docs,source:{originalSource:`{
  args: {
    userId: 'henry'
  }
}`,...(p=(i=s.parameters)==null?void 0:i.docs)==null?void 0:p.source}}};var n,c,m;t.parameters={...t.parameters,docs:{...(n=t.parameters)==null?void 0:n.docs,source:{originalSource:`{
  render: DarkTemplate,
  args: {
    userId: 'tom'
  }
}`,...(m=(c=t.parameters)==null?void 0:c.docs)==null?void 0:m.source}}};const v=["Default","Dark"];export{t as Dark,s as Default,v as __namedExportsOrder,S as default};
