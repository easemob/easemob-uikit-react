import{j as a}from"./jsx-runtime-CiKstLBL.js";import{T as m}from"./AudioMessage-nvljx91n.js";import{P as y}from"./Provider-DijW63BH.js";import"./index-CoXXcpNP.js";import"./index-DnM5vpkX.js";import"./index-PtjWlFZj.js";import"./MessageStatus-Q5VJSgQa.js";import"./Icon-CScj7eB3.js";import"./reactNode-CrwpwiaA.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-S3NOQ7Fp.js";import"./index-RzZosPvc.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";import"./useAddress-B7gFrhkG.js";const e="zh",t={en:{textMessage:"textMessage",type:"type",prefix:"prefix",className:"className",bubbleClass:"bubbleClass",children:"children",style:"style",onCreateThread:"Callback when creating a thread",onTranslateTextMessage:"Callback when translating text message",targetLanguage:"The target language to be translated into",showTranslation:"Whether to show the translated message",onlyContent:"Whether to only display the content",onOpenThreadPanel:"Callback when opening the thread panel",showEditedTag:"Whether to show the edited tag"},zh:{textMessage:"文本消息",type:"类型",prefix:"前缀",className:"类名",bubbleClass:"气泡类名",children:"子元素",style:"样式",onCreateThread:"创建线程",onTranslateTextMessage:"翻译文本消息",targetLanguage:"目标语言",showTranslation:"是否展示翻译后的消息",onlyContent:"是否只展示内容",onOpenThreadPanel:"打开线程面板",showEditedTag:"是否展示编辑标签"}},k={title:"Module/TextMessage",component:m,argTypes:{prefix:{description:t[e].prefix,control:{type:"text"}},className:{description:t[e].className,control:{type:"text"}},bubbleClass:{description:t[e].bubbleClass,control:{type:"text"}},children:{description:t[e].children},style:{description:t[e].style,control:{type:"object"}},textMessage:{description:t[e].textMessage,control:{type:"object"},table:{type:{summary:"TextMessageType"},defaultValue:{summary:"TextMessageType"}}},showTranslation:{description:t[e].showTranslation,control:{type:"boolean"}},targetLanguage:{description:t[e].targetLanguage,control:{type:"text"}},type:{description:t[e].type,control:{type:"select",options:["primary","secondly"]}},onCreateThread:{description:t[e].onCreateThread},onlyContent:{description:t[e].onlyContent,control:{type:"boolean"}},onOpenThreadPanel:{description:t[e].onOpenThreadPanel},showEditedTag:{description:t[e].showEditedTag,control:{type:"boolean"}}}},c=g=>a.jsx(y,{initConfig:{appKey:"a#b"},children:a.jsx(m,{...g})}),n={render:c,args:{textMessage:{type:"txt",msg:"hello",id:"1234567890",to:"userId",chatType:"singleChat",bySelf:!0,from:"myUserId",time:Date.now(),status:"sent",modifiedInfo:{operatorId:"",operationCount:0,operationTime:0}}}},o={render:c,args:{textMessage:{id:"1189528432543795984",type:"txt",chatType:"singleChat",msg:"asd",to:"zd4",from:"zd2",ext:{em_at_list:[],msgQuote:{msgID:"1187658028808145668",msgPreview:"Start a video call",msgSender:"zd4",msgType:"txt"}},time:1694523470608,onlineState:3,status:"sent",modifiedInfo:{operatorId:"",operationCount:0,operationTime:0},bySelf:!1}}};var s,r,i;n.parameters={...n.parameters,docs:{...(s=n.parameters)==null?void 0:s.docs,source:{originalSource:`{
  render: Template,
  args: {
    textMessage: {
      type: 'txt',
      msg: 'hello',
      id: '1234567890',
      to: 'userId',
      chatType: 'singleChat',
      bySelf: true,
      from: 'myUserId',
      time: Date.now(),
      status: 'sent',
      modifiedInfo: {
        operatorId: '',
        operationCount: 0,
        operationTime: 0
      }
    }
  }
}`,...(i=(r=n.parameters)==null?void 0:r.docs)==null?void 0:i.source}}};var p,l,d;o.parameters={...o.parameters,docs:{...(p=o.parameters)==null?void 0:p.docs,source:{originalSource:`{
  render: Template,
  args: {
    textMessage: {
      id: '1189528432543795984',
      type: 'txt',
      chatType: 'singleChat',
      msg: 'asd',
      to: 'zd4',
      from: 'zd2',
      ext: {
        em_at_list: [],
        msgQuote: {
          msgID: '1187658028808145668',
          msgPreview: 'Start a video call',
          msgSender: 'zd4',
          msgType: 'txt'
        }
      },
      time: 1694523470608,
      onlineState: 3,
      status: 'sent',
      modifiedInfo: {
        operatorId: '',
        operationCount: 0,
        operationTime: 0
      },
      bySelf: false
    }
  }
}`,...(d=(l=o.parameters)==null?void 0:l.docs)==null?void 0:d.source}}};const R=["Primary","TextMessageWithReply"];export{n as Primary,o as TextMessageWithReply,R as __namedExportsOrder,k as default};
