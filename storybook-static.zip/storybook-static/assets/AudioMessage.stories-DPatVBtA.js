import{j as a}from"./jsx-runtime-CiKstLBL.js";import{P as y}from"./Provider-DijW63BH.js";import{A as m}from"./AudioMessage-nvljx91n.js";import"./index-CoXXcpNP.js";import"./rootContext-c98KtOd0.js";import"./index-DzFcepMq.js";import"./index-ux5NTfpI.js";import"./Tooltip-u8NvX5SI.js";import"./index-DnM5vpkX.js";import"./index-S3NOQ7Fp.js";import"./index-PtjWlFZj.js";import"./reactNode-CrwpwiaA.js";import"./index-RzZosPvc.js";import"./Icon-CScj7eB3.js";import"./useAddress-B7gFrhkG.js";import"./MessageStatus-Q5VJSgQa.js";import"./Modal-BfMZBOgd.js";import"./Button-DkmWd_yB.js";import"./Ripple-C_wTLl8Y.js";import"./Emoji-37DYiqy7.js";import"./Checkbox-CDjsaAO6.js";import"./UserProfile-BjPQF8r1.js";const e="zh",t={en:{audioMessage:"Audio message received from SDK",prefix:"Prefix",style:"Style",className:"Class name",bubbleClass:"Bubble class name",type:"Bubble type",onlyContent:"Only show content, not bubble"},zh:{audioMessage:"从SDK收到的语音消息",prefix:"组件类名前缀",style:"组件样式",className:"组件类名",bubbleClass:"气泡类名",type:"气泡类型",onlyContent:"只显示内容, 不显示气泡"}},B={title:"Module/AudioMessage",component:m,argTypes:{audioMessage:{control:{type:"object"},description:t[e].audioMessage},prefix:{control:{type:"text"},description:t[e].prefix},style:{control:{type:"object"},description:t[e].style},className:{control:{type:"text"},description:t[e].className},bubbleClass:{control:{type:"text"},description:t[e].bubbleClass},type:{control:"select",options:["primary","secondly"],description:t[e].type},onlyContent:{control:{type:"boolean"},description:t[e].onlyContent}}},u=c=>a.jsx(y,{initConfig:{appKey:"a#b"},children:a.jsx(m,{...c})}),n={render:u,args:{type:"primary",audioMessage:{type:"audio",filename:"audio.wav",length:3,file_length:1024,chatType:"singleChat",time:Date.now(),status:"read",bySelf:!0,file:{url:"hppt://example",filename:"string",filetype:"audio",data:{},length:3,duration:3},id:"12345678901",to:"userId",from:"myId"}}},o={render:u,args:{type:"secondly",direction:"ltr",audioMessage:{type:"audio",filename:"audio.wav",length:3,file_length:1024,chatType:"singleChat",time:Date.now(),status:"read",bySelf:!1,file:{url:"hppt://example",filename:"string",filetype:"audio",data:{},length:3,duration:3},id:"12345678901",to:"userId",from:"myId"}}};var i,r,s;n.parameters={...n.parameters,docs:{...(i=n.parameters)==null?void 0:i.docs,source:{originalSource:`{
  render: Template,
  args: {
    type: 'primary',
    audioMessage: {
      type: 'audio',
      filename: 'audio.wav',
      length: 3,
      file_length: 1024,
      chatType: 'singleChat',
      time: Date.now(),
      status: 'read',
      bySelf: true,
      file: {
        url: 'hppt://example',
        filename: 'string',
        filetype: 'audio',
        data: {} as unknown as File,
        length: 3,
        duration: 3
      },
      id: '12345678901',
      to: 'userId',
      from: 'myId'
    }
  }
}`,...(s=(r=n.parameters)==null?void 0:r.docs)==null?void 0:s.source}}};var l,p,d;o.parameters={...o.parameters,docs:{...(l=o.parameters)==null?void 0:l.docs,source:{originalSource:`{
  render: Template,
  args: {
    type: 'secondly',
    direction: 'ltr',
    audioMessage: {
      type: 'audio',
      filename: 'audio.wav',
      length: 3,
      file_length: 1024,
      chatType: 'singleChat',
      time: Date.now(),
      status: 'read',
      bySelf: false,
      file: {
        url: 'hppt://example',
        filename: 'string',
        filetype: 'audio',
        data: {} as unknown as File,
        length: 3,
        duration: 3
      },
      id: '12345678901',
      to: 'userId',
      from: 'myId'
    }
  }
}`,...(d=(p=o.parameters)==null?void 0:p.docs)==null?void 0:d.source}}};const E=["Primary","Secondly"];export{n as Primary,o as Secondly,E as __namedExportsOrder,B as default};
